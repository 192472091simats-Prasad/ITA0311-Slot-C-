set ns [new Simulator]
set nf [open out.nam w]
$ns namtrace-all $nf

set n0 [$ns node]
set n1 [$ns node]
set n2 [$ns node]
set n3 [$ns node]
$ns duplex-link $n0 $n2 2Mb 10ms DropTail
$ns duplex-link $n1 $n2 2Mb 10ms DropTail
$ns duplex-link $n2 $n3 1Mb 20ms DropTail

set tcp [$ns create-connection TCP $n0 TCPSink $n3 0]
set udp [$ns create-connection UDP $n1 Null $n3 1]

set ftp [new Application/FTP]
$ftp attach-agent $tcp
set cbr [new Application/Traffic/CBR]
$cbr attach-agent $udp

$ns at 0.5 "$ftp start"
$ns at 1.0 "$cbr start"
$ns at 5.0 "$ns flush-trace; exec nam out.nam &; exit 0"
$ns run
