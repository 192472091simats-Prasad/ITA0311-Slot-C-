#!/bin/bash
# Runs each experiment in NS2, opens NAM on a virtual display, plays it,
# and saves REAL screenshots as real_nam_1.png, real_nam_2.png ... in each folder.
# Setup (Ubuntu/WSL2):  sudo apt install ns2 nam xvfb xdotool imagemagick
cd "$(dirname "$0")"
for d in Exp*/; do
  ( cd "$d"
    sed 's/exec nam out.nam &; //' a.tcl > run.tcl      # run headless, open NAM ourselves
    ns run.tcl
    export DISPLAY=:99; Xvfb :99 -screen 0 1280x800x24 & XV=$!; sleep 1
    nam out.nam & NP=$!; sleep 3
    xdotool mousemove 40 60 2>/dev/null
    for i in 1 2 3 4; do
      xdotool key space 2>/dev/null; sleep 1.5      # play/pause
      import -window root "real_nam_$i.png"
    done
    kill $NP $XV 2>/dev/null; rm -f run.tcl )
done
echo "Done. Real screenshots saved in each Exp folder."
