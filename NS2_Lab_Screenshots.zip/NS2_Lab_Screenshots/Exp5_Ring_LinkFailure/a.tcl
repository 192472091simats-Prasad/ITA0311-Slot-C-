set ns [new Simulator]
$ns rtproto DV
set nf [open out.nam w]
$ns namtrace-all $nf

for {set i 0} {$i < 4} {incr i} {
    set n($i) [$ns node]
}
for {set i 0} {$i < 4} {incr i} {
    $ns duplex-link $n($i) $n([expr ($i+1)%4]) 1Mb 10ms DropTail
}

set udp [$ns create-connection UDP $n(0) Null $n(2) 0]
set cbr [new Application/Traffic/CBR]
$cbr attach-agent $udp

$ns at 0.5 "$cbr start"
$ns rtmodel-at 2.0 down $n(1) $n(2)
$ns rtmodel-at 3.0 up $n(1) $n(2)
$ns at 5.0 "$ns flush-trace; exec nam out.nam &; exit 0"
$ns run
